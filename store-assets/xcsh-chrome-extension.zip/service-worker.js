// src/vendored-resolver.ts
var KNOWN_ROLES = new Set([
  "button",
  "tab",
  "option",
  "textbox",
  "spinbutton",
  "listbox",
  "combobox",
  "checkbox",
  "radio",
  "switch",
  "link",
  "menuitem",
  "searchbox",
  "slider",
  "treeitem"
]);
var TEXT_RE = /^text\('([^']*)'\)$/;
var ROLE_TEXT_RE = /^([a-z]+):text\('([^']*)'\)$/;
var ROLE_NAME_RE = /^([a-z]+)\[name='([^']*)'\]$/;
var BARE_ROLE_RE = /^[a-z]+$/;
function parseLocator(selector) {
  const text = selector.match(TEXT_RE);
  if (text)
    return { kind: "text", text: text[1] };
  const roleText = selector.match(ROLE_TEXT_RE);
  if (roleText)
    return { kind: "roleName", role: roleText[1], name: roleText[2] };
  const roleName = selector.match(ROLE_NAME_RE);
  if (roleName)
    return { kind: "roleName", role: roleName[1], name: roleName[2] };
  if (BARE_ROLE_RE.test(selector) && KNOWN_ROLES.has(selector))
    return { kind: "role", role: selector };
  return { kind: "css", css: selector };
}

class NotFoundError extends Error {
  constructor(message) {
    super(message);
    this.name = "NotFoundError";
  }
}

class AmbiguousError extends Error {
  constructor(message) {
    super(message);
    this.name = "AmbiguousError";
  }
}
function norm(s) {
  return s.trim().replace(/\s+/g, " ");
}
function collect(node, results) {
  results.push(node);
  for (const child of node.children ?? []) {
    collect(child, results);
  }
}
function matchNode(tree, loc) {
  if (loc.kind === "css") {
    throw new Error("css locators cannot be resolved against an AX tree — resolve live via CDP");
  }
  const all = [];
  collect(tree, all);
  let matches;
  if (loc.kind === "roleName") {
    const wantRole = loc.role;
    const wantName = norm(loc.name);
    matches = all.filter((n) => {
      if (n.role !== wantRole)
        return false;
      const nodeName = norm(n.name ?? "");
      return nodeName === wantName;
    });
  } else if (loc.kind === "role") {
    matches = all.filter((n) => n.role === loc.role);
  } else {
    const want = norm(loc.text);
    matches = all.filter((n) => {
      const nodeName = norm(n.name ?? "");
      return nodeName === want || nodeName.includes(want);
    });
  }
  if (matches.length === 0) {
    let hint = "";
    if (loc.kind === "roleName" || loc.kind === "role") {
      const sameRole = all.filter((n) => n.role === loc.role && n.name).map((n) => JSON.stringify(n.name));
      if (sameRole.length > 0) {
        hint = ` (same-role candidates: ${sameRole.slice(0, 5).join(", ")})`;
      }
    } else if (loc.kind === "text") {
      const textCandidates = [];
      const seen = new Set;
      for (const node of all) {
        if (node.name) {
          const normalized = norm(node.name);
          if (normalized.length > 0 && !seen.has(normalized)) {
            seen.add(normalized);
            textCandidates.push(JSON.stringify(normalized));
            if (textCandidates.length >= 5)
              break;
          }
        }
      }
      if (textCandidates.length > 0) {
        hint = ` (nearby text candidates: ${textCandidates.join(", ")})`;
      }
    }
    throw new NotFoundError(`No AX node found for ${JSON.stringify(loc)}${hint}`);
  }
  if (loc.kind === "text") {
    return matches[0];
  }
  if (matches.length > 1) {
    const names = matches.map((n) => JSON.stringify(n.name ?? n.role));
    throw new AmbiguousError(`${matches.length} AX nodes match ${JSON.stringify(loc)}: ${names.slice(0, 5).join(", ")}`);
  }
  return matches[0];
}
function matchNodes(tree, loc) {
  if (loc.kind === "css") {
    throw new Error("css locators cannot be resolved against an AX tree — resolve live via CDP");
  }
  const all = [];
  collect(tree, all);
  if (loc.kind === "roleName") {
    const wantRole = loc.role;
    const wantName = norm(loc.name);
    return all.filter((n) => n.role === wantRole && norm(n.name ?? "") === wantName);
  } else if (loc.kind === "role") {
    return all.filter((n) => n.role === loc.role);
  } else {
    const want = norm(loc.text);
    return all.filter((n) => {
      const nodeName = norm(n.name ?? "");
      return nodeName === want || nodeName.includes(want);
    });
  }
}

// src/service-worker.ts
var NATIVE_HOST = "com.f5xc.xcsh.chrome_host";
var RECONNECT_ALARM = "reconnect";
var MANAGED_POLICY_ALARM = "managed-policy-refresh";
var VERSION = "0.1.0";
var NAV_TIMEOUT_MS = 30000;
var MAX_JS_CODE_LEN = 1e5;
var managedPolicy = {};
async function refreshManagedPolicy() {
  try {
    const stored = await chrome.storage.managed.get([
      "allowedDomains",
      "blockedUrlPatterns",
      "confirmBeforeMutating"
    ]);
    managedPolicy = {
      allowedDomains: Array.isArray(stored.allowedDomains) ? stored.allowedDomains : undefined,
      blockedUrlPatterns: Array.isArray(stored.blockedUrlPatterns) ? stored.blockedUrlPatterns : undefined,
      confirmBeforeMutating: typeof stored.confirmBeforeMutating === "boolean" ? stored.confirmBeforeMutating : undefined
    };
  } catch {}
}
function isBlockedUrl(url) {
  const patterns = managedPolicy.blockedUrlPatterns;
  if (!patterns || patterns.length === 0)
    return false;
  let normalized;
  try {
    const parsed = new URL(url);
    normalized = decodeURIComponent(`${parsed.origin}${parsed.pathname}${parsed.search}`).toLowerCase();
  } catch {
    normalized = decodeURIComponent(url).toLowerCase();
  }
  return patterns.some((p) => typeof p === "string" && p.length > 0 && normalized.includes(p.toLowerCase()));
}
var SCOPED_QUERY_PATTERNS = [
  "https://*.volterra.us/*",
  "https://*.console.ves.volterra.io/*"
];
function isScopedUrl(url) {
  return /^https:\/\/[^/]*\.volterra\.us\//.test(url) || /^https:\/\/[^/]*\.console\.ves\.volterra\.io\//.test(url);
}
var KC_LOGIN_HOST = /(?:^|\.)volterra\.us$|(?:^|\.)console\.ves\.volterra\.io$/;
function isKeycloakLoginUrl(u) {
  try {
    const { hostname, pathname } = new URL(u);
    return KC_LOGIN_HOST.test(hostname) && /\/auth\/realms\/|\/login-actions\//.test(pathname);
  } catch {
    return false;
  }
}
var port = null;
var targetTabId;
var lastLoginCredentials = null;
var attachedTabs = new Set;
var ALLOWED_PATTERNS = [
  "https://*.volterra.us/*",
  "https://*.console.ves.volterra.io/*"
];
var consoleBuffer = [];
var networkBuffer = [];
var observingConsole = false;
var observingNetwork = false;
async function enableConsoleObserver() {
  if (observingConsole)
    return;
  const tabId = requireTab();
  await ensureDebuggerAttached(tabId);
  await chrome.debugger.sendCommand({ tabId }, "Runtime.enable", {});
  observingConsole = true;
}
async function enableNetworkObserver() {
  if (observingNetwork)
    return;
  const tabId = requireTab();
  await ensureDebuggerAttached(tabId);
  await chrome.debugger.sendCommand({ tabId }, "Network.enable", {});
  observingNetwork = true;
}
chrome.debugger.onEvent.addListener((source, method, eventParams) => {
  if (source.tabId === undefined)
    return;
  if (method === "Page.javascriptDialogOpening") {
    chrome.debugger.sendCommand({ tabId: source.tabId }, "Page.handleJavaScriptDialog", { accept: true }).catch(() => {});
    return;
  }
  if (source.tabId !== targetTabId)
    return;
  if (method === "Runtime.consoleAPICalled") {
    consoleBuffer.push(eventParams);
    if (consoleBuffer.length > 500)
      consoleBuffer.shift();
  } else if (method === "Network.requestWillBeSent" || method === "Network.responseReceived") {
    networkBuffer.push({ method, ...eventParams });
    if (networkBuffer.length > 500)
      networkBuffer.shift();
  }
});
function connect() {
  if (port)
    return;
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST);
    port.onMessage.addListener(onMessage);
    port.onDisconnect.addListener(() => {
      port = null;
    });
  } catch {
    port = null;
  }
}
function onMessage(msg) {
  if (!msg || typeof msg !== "object")
    return;
  if (msg.type === "ping") {
    port?.postMessage({ type: "pong" });
    return;
  }
  if (msg.type === "tool_request") {
    const { id, tool, params } = msg;
    runTool(tool, params).then((content) => {
      port?.postMessage({ type: "tool_result", id, content, is_error: false });
    }).catch((e) => {
      port?.postMessage({
        type: "tool_result",
        id,
        content: String(e),
        is_error: true
      });
    });
  }
}
connect();
refreshManagedPolicy();
chrome.storage.onChanged.addListener((_changes, areaName) => {
  if (areaName === "managed") {
    refreshManagedPolicy();
  }
});
chrome.alarms.create(RECONNECT_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.create(MANAGED_POLICY_ALARM, { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RECONNECT_ALARM && !port) {
    connect();
  } else if (alarm.name === MANAGED_POLICY_ALARM) {
    refreshManagedPolicy();
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object")
    return;
  if (msg.type === "status_request") {
    sendResponse({ connected: !!port });
    return;
  }
  if (msg.type === "stop_agent") {
    stopAgent();
    return;
  }
});
function stopAgent() {
  if (targetTabId !== undefined) {
    detach().catch(() => {});
  }
  chrome.tabs.query({ url: SCOPED_QUERY_PATTERNS }).then((tabs) => {
    for (const tab of tabs) {
      if (tab.id !== undefined) {
        chrome.tabs.sendMessage(tab.id, { type: "indicator_hide" }).catch(() => {});
      }
    }
  });
}
async function runTool(tool, params) {
  const broadcastsIndicator = tool !== "ping";
  if (broadcastsIndicator && targetTabId !== undefined) {
    chrome.tabs.sendMessage(targetTabId, { type: "indicator_show" }).catch(() => {});
  }
  try {
    return await dispatchTool(tool, params);
  } finally {
    if (broadcastsIndicator && targetTabId !== undefined) {
      chrome.tabs.sendMessage(targetTabId, { type: "indicator_hide" }).catch(() => {});
    }
  }
}
async function dispatchTool(tool, params) {
  switch (tool) {
    case "ping":
      return { ok: true, version: VERSION };
    case "reload": {
      chrome.runtime.reload();
      return { reloading: true };
    }
    case "debug_exec": {
      const tabId = requireTab();
      return evalInPage(tabId, "({ts:Date.now(),title:document.title,xcsh:typeof __xcshReadAx})");
    }
    case "navigate":
      return navigate(params);
    case "login":
      return login(params);
    case "select_option":
      return selectOption(params);
    case "scroll_to":
      return scrollTo(params);
    case "get_page_text":
      return getPageText();
    case "javascript_tool":
      return javascriptTool(params);
    case "tabs_list":
      return tabsList();
    case "tabs_create":
      return tabsCreate(params);
    case "tabs_close":
      return tabsClose(params);
    case "resize_window":
      return resizeWindow(params);
    case "read_console":
      return readConsole(params);
    case "read_network":
      return readNetwork(params);
    case "file_upload":
      return fileUpload(params);
    case "browser_batch":
      return browserBatch(params);
    case "read_ax":
      return readAx();
    case "wait_for":
      return waitFor(params);
    case "assert_text":
      return assertText(params);
    case "find":
      return find(params);
    case "click":
      return click(params);
    case "screenshot":
      return screenshot();
    case "form_input":
      return formInput(params);
    case "key_press":
      return keyPress(params);
    case "detach":
      return detach();
    default:
      throw new Error(`unknown tool: ${tool}`);
  }
}
async function navigate(params) {
  const url = params?.url;
  if (typeof url !== "string" || !isScopedUrl(url)) {
    throw new Error(`navigate: url not in scoped console domains: ${url}`);
  }
  let scheme;
  try {
    scheme = new URL(url).protocol;
  } catch {
    throw new Error(`navigate: invalid url: ${url}`);
  }
  if (scheme !== "https:") {
    throw new Error(`navigate: only https: urls are allowed, got ${scheme}`);
  }
  if (isBlockedUrl(url)) {
    throw new Error(`navigate: url blocked by managed policy: ${url}`);
  }
  let reuseId;
  if (targetTabId !== undefined) {
    try {
      const t = await chrome.tabs.get(targetTabId);
      if (t.id !== undefined)
        reuseId = t.id;
    } catch {}
  }
  if (reuseId === undefined) {
    const existing = await chrome.tabs.query({ url: SCOPED_QUERY_PATTERNS });
    if (existing.length > 0 && existing[0].id !== undefined)
      reuseId = existing[0].id;
  }
  let tabId;
  if (reuseId !== undefined) {
    targetTabId = reuseId;
    tabId = reuseId;
    try {
      const current = await chrome.tabs.get(tabId);
      if (current.url && current.url.split("?")[0] === url.split("?")[0]) {
        return { tabId };
      }
    } catch {}
    try {
      await ensureDebuggerAttached(tabId);
      await chrome.debugger.sendCommand({ tabId }, "Page.navigate", { url });
    } catch {
      await chrome.tabs.update(tabId, { url, active: true });
    }
  } else {
    const created = await chrome.tabs.create({ url, active: true });
    if (created.id === undefined) {
      throw new Error("navigate: failed to create console tab");
    }
    targetTabId = created.id;
    tabId = created.id;
  }
  await waitForNavigation(tabId);
  await recoverFromCsrf(tabId);
  await waitForSettle(tabId);
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.url && isKeycloakLoginUrl(tab.url) && lastLoginCredentials) {
      await login(lastLoginCredentials);
      try {
        await ensureDebuggerAttached(tabId);
        await chrome.debugger.sendCommand({ tabId }, "Page.navigate", { url });
      } catch {
        await chrome.tabs.update(tabId, { url, active: true });
      }
      await waitForNavigation(tabId);
      await waitForSettle(tabId);
    }
  } catch {}
  return { tabId };
}
async function recoverFromCsrf(tabId) {
  for (let attempt = 0;attempt < 2; attempt++) {
    let isCsrf = false;
    try {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => /invalid csrf token|csrf token/i.test((document.body && document.body.innerText || "").slice(0, 500))
      });
      isCsrf = r?.result === true;
    } catch {
      return;
    }
    if (!isCsrf)
      return;
    await chrome.tabs.reload(tabId);
    await waitForNavigation(tabId);
    await new Promise((r) => setTimeout(r, 1500));
  }
}
async function waitForSettle(tabId, timeoutMs = 15000) {
  let last = -1;
  let stable = 0;
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline && stable < 3) {
    let count = 0;
    try {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => document.querySelectorAll("*").length
      });
      count = r?.result ?? 0;
    } catch {}
    if (count > 50 && count === last)
      stable++;
    else
      stable = 0;
    last = count;
    await new Promise((r) => setTimeout(r, 500));
  }
}
async function login(params) {
  const { email, password, consoleUrl } = params ?? {};
  if (!email || !password || !consoleUrl) {
    throw new Error("login: email, password, and consoleUrl are required");
  }
  lastLoginCredentials = { email, password, consoleUrl };
  try {
    const parsed = new URL(consoleUrl);
    if (parsed.protocol !== "https:" || !isScopedUrl(consoleUrl)) {
      throw new Error("not a console URL");
    }
  } catch {
    throw new Error(`login: consoleUrl is not a valid F5 XC console URL: ${consoleUrl}`);
  }
  const steps = [];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const isLoginUrl = isKeycloakLoginUrl;
  const { tabId } = await navigate({ url: consoleUrl });
  steps.push(`navigate → ${consoleUrl}`);
  const detectDeadline = Date.now() + 30000;
  let onLoginForm = false;
  while (Date.now() < detectDeadline) {
    const tab = await chrome.tabs.get(tabId);
    const url = tab.url ?? "";
    if (isLoginUrl(url)) {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => ({
          form: !!document.querySelector("#username, #password"),
          invalid: /invalid username or password/i.test(document.body?.innerText ?? ""),
          href: location.href
        })
      });
      const res = r?.result;
      if (res?.form) {
        steps.push(`302 → Keycloak login page (${new URL(url).hostname})`);
        onLoginForm = true;
        break;
      }
    } else if (isScopedUrl(url) && !url.includes("code=") && !url.includes("state=")) {
      steps.push("already authenticated — console loaded");
      await waitForSettle(tabId);
      return { loggedIn: true, finalUrl: (await chrome.tabs.get(tabId)).url ?? url, steps };
    }
    await sleep(800);
  }
  if (!onLoginForm) {
    throw new Error("login: Keycloak login form did not appear within 30s");
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (em, pw) => {
      const u = document.querySelector("#username, input[name='username']");
      const p = document.querySelector("#password, input[name='password']");
      if (u) {
        u.value = em;
        u.dispatchEvent(new Event("input", { bubbles: true }));
        u.dispatchEvent(new Event("change", { bubbles: true }));
      }
      if (p) {
        p.value = pw;
        p.dispatchEvent(new Event("input", { bubbles: true }));
        p.dispatchEvent(new Event("change", { bubbles: true }));
      }
      const btn = document.querySelector("#kc-login, button[type='submit'], input[type='submit']");
      btn?.click();
    },
    args: [email, password]
  });
  steps.push("submitted credentials → #kc-login");
  const authDeadline = Date.now() + 40000;
  while (Date.now() < authDeadline) {
    await sleep(1000);
    const tab = await chrome.tabs.get(tabId);
    const url = tab.url ?? "";
    if (isScopedUrl(url) && !isLoginUrl(url)) {
      steps.push(`302 → console (${new URL(url).hostname}) — authenticated`);
      await recoverFromCsrf(tabId);
      await waitForSettle(tabId);
      return { loggedIn: true, finalUrl: (await chrome.tabs.get(tabId)).url ?? url, steps };
    }
    if (isLoginUrl(url)) {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const invalid = /invalid username or password|account is disabled/i.test(document.body?.innerText ?? "");
          if (invalid)
            return "invalid";
          const isInterstitial = /required-action|login-actions\/(authenticate|action-token)/.test(location.pathname);
          if (!isInterstitial)
            return "waiting";
          const hasOtp = !!document.querySelector("#otp, input[name='totp'], input[name='otp']");
          if (hasOtp)
            return "mfa-required";
          const execParam = new URLSearchParams(location.search).get("execution") ?? "";
          const execType = execParam.toUpperCase();
          if (execType.includes("PASSWORD"))
            return "password-change-required";
          if (execType.includes("VERIFY_EMAIL"))
            return "email-verification-required";
          if (execType.includes("CONFIGURE_TOTP"))
            return "totp-setup-required";
          const submit = document.querySelector("input[type='submit'], button[type='submit'], #kc-login");
          if (submit) {
            submit.click();
            return "interstitial-submitted:" + execType;
          }
          return "waiting";
        }
      });
      const state = r?.result ?? "";
      if (state === "invalid") {
        throw new Error("login: invalid username or password");
      }
      if (state === "mfa-required") {
        throw new Error("login: MFA TOTP code required — either set F5XC_TOTP_SECRET in your xcsh context or complete the 2FA prompt in the visible Chrome window");
      }
      if (state === "password-change-required") {
        throw new Error("login: password change required — update your password in the visible Chrome window, then retry");
      }
      if (state === "email-verification-required") {
        throw new Error("login: email verification required — check your email, then retry");
      }
      if (state === "totp-setup-required") {
        throw new Error("login: MFA TOTP setup required — complete the setup in the visible Chrome window, then retry");
      }
      if (state.startsWith("interstitial-submitted")) {
        steps.push(`handled Keycloak required-action interstitial (${state.split(":")[1] ?? ""})`);
      }
    }
  }
  const finalTab = await chrome.tabs.get(tabId);
  throw new Error(`login: did not reach the console within 40s (stuck on ${finalTab.url?.slice(0, 70)})`);
}
function waitForNavigation(tabId) {
  return new Promise((resolve) => {
    let settled = false;
    const onCompleted = (details) => {
      if (details.tabId === tabId && details.frameId === 0) {
        finish();
      }
    };
    const timer = setTimeout(finish, NAV_TIMEOUT_MS);
    function finish() {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      chrome.webNavigation.onCompleted.removeListener(onCompleted);
      resolve();
    }
    chrome.webNavigation.onCompleted.addListener(onCompleted);
  });
}
function requireTab() {
  if (targetTabId === undefined) {
    throw new Error("no target tab — call navigate first");
  }
  return targetTabId;
}
async function evalInPage(tabId, expression) {
  await ensureDebuggerAttached(tabId);
  const r = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: false
  });
  if (r.exceptionDetails) {
    throw new Error(`evalInPage error: ${r.exceptionDetails.text ?? "unknown"}`);
  }
  return r.result?.value;
}
async function readAxFromTab() {
  const tabId = requireTab();
  await ensureDebuggerAttached(tabId);
  const isAvailable = await evalInPage(tabId, "typeof __xcshReadAx === 'function'");
  if (!isAvailable) {
    const code = await (await fetch(chrome.runtime.getURL("accessibility-tree.js"))).text();
    await evalInPage(tabId, code);
  }
  for (let attempt = 0;attempt < 6; attempt++) {
    try {
      const r = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
        expression: "typeof __xcshReadAx === 'function' ? JSON.stringify(__xcshReadAx()) : null",
        returnByValue: true
      });
      const json = r?.result?.value;
      if (json) {
        const tree = JSON.parse(json);
        if (tree && typeof tree === "object" && "role" in tree)
          return tree;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("read_ax: __xcshReadAx not available via debugger (page may still be loading)");
}
async function readAx() {
  return readAxFromTab();
}
async function waitFor(params) {
  const selector = params?.selector;
  const timeoutMs = params?.timeoutMs ?? 30000;
  const loc = parseLocator(selector);
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const tree = await readAxFromTab();
    try {
      const node = matchNode(tree, loc);
      return { found: true, ref: node.ref };
    } catch {
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  throw new Error(`wait_for "${selector}" timed out after ${timeoutMs}ms`);
}
async function assertText(params) {
  const tabId = requireTab();
  const { selector, expected } = params;
  const tree = await readAxFromTab();
  const node = matchNode(tree, parseLocator(selector));
  let text = node.name ?? "";
  if (!text.includes(expected) && node.ref) {
    text = await evalInPage(tabId, `typeof __xcshGetInnerText==='function'?__xcshGetInnerText(${JSON.stringify(node.ref)}):''`);
  }
  if (!text.includes(expected)) {
    throw new Error(`assert failed: "${expected}" not in "${text.slice(0, 200)}"`);
  }
  return { asserted: true, text: text.slice(0, 200) };
}
async function find(params) {
  const { selector } = params;
  const tree = await readAxFromTab();
  const nodes = matchNodes(tree, parseLocator(selector));
  return {
    refs: nodes.slice(0, 20).map((n) => ({
      ref: n.ref,
      role: n.role,
      name: n.name ?? ""
    }))
  };
}
async function click(params) {
  const tabId = requireTab();
  const ref = params?.ref;
  if (!ref)
    throw new Error("click: ref is required");
  const coords = await evalInPage(tabId, `typeof __xcshResolveRef === 'function' ? __xcshResolveRef(${JSON.stringify(ref)}) : null`);
  if (!coords)
    throw new Error(`click: could not resolve ref: ${ref}`);
  const { x, y } = coords;
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mousePressed",
    x,
    y,
    button: "left",
    clickCount: 1
  });
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x,
    y,
    button: "left",
    clickCount: 1
  });
  return { clicked: ref, x, y };
}
async function screenshot() {
  const tabId = requireTab();
  await ensureDebuggerAttached(tabId);
  const data = await evalInPage(tabId, `
    (() => {
      try {
        const c = document.createElement('canvas');
        const w = Math.min(window.innerWidth, 1280);
        const h = Math.min(window.innerHeight, 800);
        const scale = Math.min(1, 600 / w); // downscale to ~600px wide
        c.width = Math.round(w * scale);
        c.height = Math.round(h * scale);
        const ctx = c.getContext('2d');
        // drawWindow is Firefox-only; for Chrome, return a placeholder.
        // The real screenshot needs html2canvas or a server-side capture.
        return 'SCREENSHOT_NOT_AVAILABLE_IN_PAGE_CONTEXT';
      } catch (e) { return 'error:' + e.message; }
    })()
  `);
  if (data === "SCREENSHOT_NOT_AVAILABLE_IN_PAGE_CONTEXT") {
    throw new Error("screenshot: in-page canvas capture not supported in Chrome (captureVisibleTab freezes SW on this retina display; screenshot deferred to a future release)");
  }
  return { data, format: "jpeg" };
}
async function formInput(params) {
  const tabId = requireTab();
  const ref = params?.ref;
  const value = params?.value;
  if (!ref)
    throw new Error("form_input: ref is required");
  await evalInPage(tabId, `__xcshCommitInputValue(${JSON.stringify(ref)}, ${JSON.stringify(value ?? "")})`);
  return { filled: ref, value };
}
var SPECIAL_KEYS = {
  Enter: { key: "Enter", code: "Enter", keyCode: 13 },
  Tab: { key: "Tab", code: "Tab", keyCode: 9 },
  Backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
  Escape: { key: "Escape", code: "Escape", keyCode: 27 },
  ArrowDown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
  ArrowUp: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
  Space: { key: " ", code: "Space", keyCode: 32 }
};
async function keyPress(params) {
  const tabId = requireTab();
  const key = params?.key;
  if (typeof key !== "string" || key.length === 0) {
    throw new Error("key_press: key is required");
  }
  let mapped;
  if (key in SPECIAL_KEYS) {
    mapped = SPECIAL_KEYS[key];
  } else if (key.length === 1) {
    const upper = key.toUpperCase();
    mapped = { key, code: `Key${upper}`, keyCode: upper.charCodeAt(0) };
  } else {
    throw new Error(`key_press: unsupported key: ${key}`);
  }
  await ensureDebuggerAttached(tabId);
  const base = {
    key: mapped.key,
    code: mapped.code,
    windowsVirtualKeyCode: mapped.keyCode
  };
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    ...base
  });
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    ...base
  });
  return { pressed: key };
}
async function detach() {
  const tabId = requireTab();
  await chrome.debugger.detach({ tabId }).catch(() => {});
  attachedTabs.delete(tabId);
  return { detached: true };
}
async function selectOption(params) {
  const tabId = requireTab();
  const { ref, value } = params;
  if (!ref)
    throw new Error("select_option: ref is required");
  const ok = await evalInPage(tabId, `typeof __xcshSelectOption==='function'?__xcshSelectOption(${JSON.stringify(ref)},${JSON.stringify(value)}):false`);
  if (!ok)
    throw new Error(`option "${value}" not found in select ${ref}`);
  return { selected: value, ref };
}
async function scrollTo(params) {
  const tabId = requireTab();
  const { ref } = params;
  if (!ref)
    throw new Error("scroll_to: ref is required");
  await evalInPage(tabId, `typeof __xcshScrollTo==='function'&&__xcshScrollTo(${JSON.stringify(ref)})`);
  return { scrolled: ref };
}
async function getPageText() {
  const tabId = requireTab();
  await ensureDebuggerAttached(tabId);
  const result = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression: "(document.body && document.body.innerText || '').slice(0, 50000)",
    returnByValue: true
  });
  return { text: result?.result?.value ?? "" };
}
async function javascriptTool(params) {
  const tabId = requireTab();
  const code = params?.code;
  if (typeof code !== "string") {
    throw new Error("javascript_tool: code is required");
  }
  if (code.length > MAX_JS_CODE_LEN) {
    throw new Error(`javascript_tool: code too large (${code.length} > ${MAX_JS_CODE_LEN})`);
  }
  const tab = await chrome.tabs.get(tabId);
  if (typeof tab.url !== "string" || !isScopedUrl(tab.url)) {
    throw new Error(`javascript_tool: tab is not on a scoped console domain: ${tab.url}`);
  }
  await ensureDebuggerAttached(tabId);
  const result = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression: code,
    returnByValue: true,
    awaitPromise: true
  });
  return { result: result?.result?.value };
}
async function tabsList() {
  const tabs = await chrome.tabs.query({ url: ALLOWED_PATTERNS });
  return {
    tabs: tabs.map((t) => ({
      id: t.id,
      url: t.url,
      title: t.title,
      active: t.active
    }))
  };
}
async function tabsCreate(params) {
  const url = params?.url;
  if (typeof url !== "string" || !isScopedUrl(url)) {
    throw new Error(`tabs_create: url not in scoped console domains: ${url}`);
  }
  if (isBlockedUrl(url)) {
    throw new Error(`tabs_create: url blocked by managed policy: ${url}`);
  }
  const tab = await chrome.tabs.create({ url, active: true });
  if (tab.id !== undefined)
    targetTabId = tab.id;
  return { tabId: tab.id };
}
async function tabsClose(params) {
  const { tabId } = params;
  await chrome.tabs.remove(tabId);
  return { closed: tabId };
}
async function resizeWindow(params) {
  const tabId = requireTab();
  const { width, height } = params;
  const tab = await chrome.tabs.get(tabId);
  if (tab.windowId !== undefined) {
    await chrome.windows.update(tab.windowId, { width, height });
  }
  return { resized: { width, height } };
}
async function readConsole(params) {
  await enableConsoleObserver();
  const pattern = params?.pattern;
  let entries = consoleBuffer.map((e) => ({
    type: e.type,
    text: (e.args ?? []).map((a) => a.value ?? a.description).join(" ")
  }));
  if (pattern)
    entries = entries.filter((e) => e.text?.includes(pattern));
  return { messages: entries.slice(-100) };
}
async function readNetwork(params) {
  await enableNetworkObserver();
  const pattern = params?.pattern;
  let entries = networkBuffer.map((e) => ({
    method: e.method,
    url: e.request?.url ?? e.response?.url,
    status: e.response?.status
  }));
  if (pattern)
    entries = entries.filter((e) => e.url?.includes(pattern));
  return { requests: entries.slice(-100) };
}
async function fileUpload(params) {
  const { ref, files } = params;
  return {
    uploaded: ref,
    fileCount: Array.isArray(files) ? files.length : 0,
    note: "file_upload full implementation is Phase 2"
  };
}
async function browserBatch(params) {
  const actions = params?.actions ?? [];
  const results = [];
  for (const action of actions) {
    try {
      const content = await runTool(action.tool, action.params);
      results.push({ tool: action.tool, content, is_error: false });
    } catch (e) {
      results.push({ tool: action.tool, content: String(e), is_error: true });
      break;
    }
  }
  return { results };
}
async function ensureDebuggerAttached(tabId) {
  if (attachedTabs.has(tabId))
    return;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.url && !isScopedUrl(tab.url)) {
      throw new Error(`tab ${tabId} is on ${tab.url} (not a console domain) — call navigate first`);
    }
  } catch (e) {
    if (/not a console domain/i.test(e?.message ?? ""))
      throw e;
  }
  try {
    await chrome.debugger.attach({ tabId }, "1.3");
    attachedTabs.add(tabId);
  } catch (e) {
    if (/already attached/i.test(e?.message ?? String(e))) {
      attachedTabs.add(tabId);
      return;
    }
    throw new Error(`chrome.debugger.attach failed for tab ${tabId}: ${e?.message ?? e}. ` + `If Chrome shows a "debugging started" bar, leave it — xcsh will retry.`);
  }
  await chrome.debugger.sendCommand({ tabId }, "Page.enable", {}).catch(() => {});
}
chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId !== undefined)
    attachedTabs.delete(source.tabId);
});
