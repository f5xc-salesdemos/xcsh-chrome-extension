(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toCommonJS = (from) => {
    var entry = (__moduleCache ??= new WeakMap).get(from), desc;
    if (entry)
      return entry;
    entry = __defProp({}, "__esModule", { value: true });
    if (from && typeof from === "object" || typeof from === "function") {
      for (var key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(entry, key))
          __defProp(entry, key, {
            get: __accessProp.bind(from, key),
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
          });
    }
    __moduleCache.set(from, entry);
    return entry;
  };
  var __moduleCache;
  var __returnValue = (v) => v;
  function __exportSetter(name, newValue) {
    this[name] = __returnValue.bind(null, newValue);
  }
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, {
        get: all[name],
        enumerable: true,
        configurable: true,
        set: __exportSetter.bind(all, name)
      });
  };

  // src/accessibility-tree.ts
  var exports_accessibility_tree = {};
  __export(exports_accessibility_tree, {
    commitInputValue: () => commitInputValue
  });

  // src/ax-serialize.ts
  var SKIP_TAGS = new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEMPLATE",
    "HEAD",
    "META",
    "LINK",
    "SVG"
  ]);
  var NOISE_ROLES = new Set(["generic", "presentation", "none", ""]);
  var NAME_FROM_CONTENT = new Set([
    "heading",
    "button",
    "link",
    "tab",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "option",
    "treeitem",
    "cell",
    "gridcell",
    "columnheader",
    "rowheader",
    "checkbox",
    "radio",
    "switch",
    "listitem",
    "tooltip"
  ]);
  var counter = 0;
  function computeRole(el) {
    const explicit = el.getAttribute("role");
    if (explicit)
      return explicit;
    const tag = el.tagName.toLowerCase();
    switch (tag) {
      case "button":
        return "button";
      case "textarea":
        return "textbox";
      case "select":
        return "combobox";
      case "a":
        return el.hasAttribute("href") ? "link" : "generic";
      case "img":
        return "img";
      case "nav":
        return "navigation";
      case "table":
        return "table";
      case "ul":
      case "ol":
        return "list";
      case "li":
        return "listitem";
      case "h1":
      case "h2":
      case "h3":
      case "h4":
      case "h5":
      case "h6":
        return "heading";
      case "input": {
        const type = (el.getAttribute("type") ?? "text").toLowerCase();
        if (type === "text" || type === "search" || type === "email" || type === "url" || type === "tel" || type === "password")
          return "textbox";
        if (type === "number")
          return "spinbutton";
        if (type === "checkbox")
          return "checkbox";
        if (type === "radio")
          return "radio";
        if (type === "button" || type === "submit")
          return "button";
        return "textbox";
      }
      default:
        return "generic";
    }
  }
  function computeName(el, role, labelMap) {
    const ariaLabel = el.getAttribute("aria-label");
    if (ariaLabel?.trim())
      return ariaLabel.trim();
    const labelledby = el.getAttribute("aria-labelledby");
    if (labelledby) {
      const doc = el.ownerDocument;
      const t = labelledby.split(/\s+/).map((id) => doc.getElementById(id)?.textContent?.replace(/\s+/g, " ").trim() ?? "").filter(Boolean).join(" ");
      if (t)
        return t;
    }
    if (role === "img")
      return el.getAttribute("alt")?.trim() ?? "";
    const tag = el.tagName.toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select") {
      const ph = el.getAttribute("placeholder");
      if (ph?.trim())
        return ph.trim();
      const id = el.getAttribute("id");
      if (id && labelMap.has(id))
        return labelMap.get(id) ?? "";
      const wrap = el.closest("label");
      const wt = wrap?.textContent?.replace(/\s+/g, " ").trim();
      if (wt)
        return wt;
      return el.getAttribute("name")?.trim() ?? "";
    }
    if (NAME_FROM_CONTENT.has(role)) {
      const text = (el.textContent ?? "").replace(/\s+/g, " ").trim();
      if (text && text.length <= 200)
        return text;
    }
    if (el.children.length === 0) {
      const text = (el.textContent ?? "").replace(/\s+/g, " ").trim();
      if (text && text.length <= 200)
        return text;
    }
    return el.getAttribute("title")?.trim() ?? "";
  }
  function buildLabelMap(doc) {
    const m = new Map;
    for (const lbl of Array.from(doc.querySelectorAll("label[for]"))) {
      const f = lbl.getAttribute("for");
      if (f)
        m.set(f, (lbl.textContent ?? "").replace(/\s+/g, " ").trim());
    }
    return m;
  }
  function walk(el, refMap, labelMap, nameClaimed) {
    const role = computeRole(el);
    const name = nameClaimed ? "" : computeName(el, role, labelMap);
    const interesting = !NOISE_ROLES.has(role) || name.length > 0;
    const claimsContent = !nameClaimed && name.length > 0 && NAME_FROM_CONTENT.has(role);
    const childClaimed = nameClaimed || claimsContent;
    const childNodes = [];
    for (const child of Array.from(el.children)) {
      if (SKIP_TAGS.has(child.tagName))
        continue;
      childNodes.push(...walk(child, refMap, labelMap, childClaimed));
    }
    if (interesting) {
      const ref = "ref_" + counter++;
      refMap.set(ref, new WeakRef(el));
      return [{ role, name, ref, children: childNodes }];
    }
    return childNodes;
  }
  function serializeAx(root, refMap) {
    counter = 0;
    const doc = root.ownerDocument ?? document;
    const labelMap = buildLabelMap(doc);
    const children = [];
    for (const child of Array.from(root.children)) {
      if (SKIP_TAGS.has(child.tagName))
        continue;
      children.push(...walk(child, refMap, labelMap, false));
    }
    const ref = "ref_" + counter++;
    refMap.set(ref, new WeakRef(root));
    return { role: "RootWebArea", name: "", ref, children };
  }

  // src/accessibility-tree.ts
  var REFMAP = new Map;
  globalThis.__xcshReadAx = () => {
    REFMAP.clear();
    return serializeAx(document.documentElement, REFMAP);
  };
  globalThis.__xcshResolveRef = (ref) => {
    const el = REFMAP.get(ref)?.deref();
    if (!el)
      return null;
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  };
  function commitInputValue(el, value) {
    let descriptor;
    let proto = Object.getPrototypeOf(el);
    while (proto) {
      descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      if (descriptor)
        break;
      proto = Object.getPrototypeOf(proto);
    }
    if (descriptor?.set)
      descriptor.set.call(el, value);
    else
      el.value = value;
    const view = el.ownerDocument?.defaultView;
    const Ev = view?.Event ?? (typeof Event !== "undefined" ? Event : undefined);
    if (Ev) {
      el.dispatchEvent(new Ev("input", { bubbles: true }));
      el.dispatchEvent(new Ev("change", { bubbles: true }));
      el.dispatchEvent(new Ev("blur", { bubbles: false }));
      el.dispatchEvent(new Ev("focusout", { bubbles: true }));
    }
  }
  globalThis.__xcshCommitInputValue = (ref, value) => {
    const el = REFMAP.get(ref)?.deref();
    if (!el)
      throw new Error(`ref ${ref} not found`);
    el.focus?.();
    commitInputValue(el, value);
  };
  globalThis.__xcshSelectOption = (ref, value) => {
    const el = REFMAP.get(ref)?.deref();
    if (!el)
      throw new Error(`ref ${ref} not found`);
    const opt = Array.from(el.options).find((o) => o.value === value || o.text === value);
    if (!opt)
      return false;
    el.value = opt.value;
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  };
  globalThis.__xcshScrollTo = (ref) => {
    const el = REFMAP.get(ref)?.deref();
    if (!el)
      throw new Error(`ref ${ref} not found`);
    el.scrollIntoView({ behavior: "smooth", block: "center" });
  };
  globalThis.__xcshGetPageText = () => {
    return (document.body?.innerText ?? "").slice(0, 50000);
  };
  globalThis.__xcshGetInnerText = (ref) => {
    const el = REFMAP.get(ref)?.deref();
    if (!el)
      throw new Error(`ref ${ref} not found`);
    return el.innerText ?? "";
  };
})();
